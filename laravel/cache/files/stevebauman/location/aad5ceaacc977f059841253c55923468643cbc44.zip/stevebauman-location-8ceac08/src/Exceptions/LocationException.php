<?php

namespace Stevebauman\Location\Exceptions;

class LocationException extends \Exception
{
    //
}
